<?php get_template_part("header"); ?>
<?php

$root_object_id = neko__get_menu_root_id($post->ID, $post->post_type, 'primary');
$parent = get_post($root_object_id);

?>
<main class="main" id="main" role="main">

<?php get_template_part('partials/banner'); ?>

<?php
rewind_posts();
if (have_posts()) {
	while (have_posts()) {
		the_post();

	$block_classes = 'block ' . ($root_object_id ? 'sidebar' : 'article');
?>
	<div class="<?php echo $block_classes; ?>" id="content">
		<div class="block__align">

			<?php get_template_part('partials/sidenav'); ?>

			<div class="block__body prose">
				<?php the_content(); ?>
			</div>
		</div>
	</div>
<?php
	}
}
?>

</main>
<!--/#main-->

<?php get_template_part("footer"); ?>
