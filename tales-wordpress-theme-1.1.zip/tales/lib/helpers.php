<?php

if (!function_exists('hex2rgb')) {
	function hex2rgb($hex)
	{
		if (preg_match('/#([0-9a-f]{1,2})([0-9a-f]{1,2})([0-9a-f]{1,2})/i', trim($hex), $rgb)) {
			return hexdec($rgb[1]).','.hexdec($rgb[2]).','.hexdec($rgb[3]);
		}
	}
}

if (!function_exists('neko__get_menu_id')) {
	function neko__get_menu_id($location)
	{
		$menu_locations = get_nav_menu_locations();
		if (is_array($menu_locations) && isset($menu_locations[$location])) {
			return $menu_locations[$location];
		}
	}
}

if (!function_exists('neko__get_menu_root_id')) {
	function neko__get_menu_root_id($post_id, $post_type, $menu_location)
	{
		$menu_items = wp_get_nav_menu_items(neko__get_menu_id($menu_location));
		if (!is_array($menu_items)) {
			return;
		}
		$top_items = array();
		$child_items = array();
		$sub_items = array();
		foreach($menu_items as $item) {
			if($item->object_id == $post_id && $item->object == $post_type) {
				$menu_item = $item;
			}
			if ($item->menu_item_parent) {
				$child_items[$item->menu_item_parent][] = $item;
			} else {
				$top_items[$item->ID] = $item;
			}
		}
		if ($menu_item->menu_item_parent) {
			return $top_items[$menu_item->menu_item_parent]->object_id;
		}
		if (array_key_exists($menu_item->ID, $child_items)) {
			$sub_items = $child_items[$menu_item->ID];
		}
		if (is_array($sub_items) && count($sub_items)) {
			return $menu_item->object_id;
		}
	}
}

?>
