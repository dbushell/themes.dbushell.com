<?php

add_action('wp_head',                'neko__customize_wp_head');
add_action('customize_register',     'neko__customize_register');
add_action('customize_preview_init', 'neko__customize_preview_init');

if (!function_exists('neko__customize_preview_init')) {
	function neko__customize_preview_init()
	{
		wp_enqueue_script('neko__customizer', get_template_directory_uri().'/assets/js/wp-customizer.min.js', array('jquery', 'customize-preview'), NEKO__VERSION, true);
	}
}

$neko__color_link_default  = '#3d9ccc';
$neko__color_hover_default = '#226181';

$neko__fonts_serif = 'Georgia, serif';
$neko__fonts_sans  = '\'Helvetica Neue\', Helvetica, Arial, sans-serif';

if (!function_exists('neko__customize_wp_head')) {
	function neko__customize_wp_head()
	{
		global $neko__color_link_default,
			   $neko__color_hover_default,
			   $neko__fonts_serif,
			   $neko__fonts_sans;

		$normal = get_theme_mod('neko__color_link', $neko__color_link_default);
		$hover  = get_theme_mod('neko__color_hover', $neko__color_hover_default);
		$serif = get_theme_mod('neko__fonts_serif', $neko__fonts_serif);
		$sans  = get_theme_mod('neko__fonts_sans', $neko__fonts_sans);
		$webfonts = get_theme_mod('neko__fonts_js');
		$favicon = get_theme_mod('neko__favicon');

		if (isset($favicon) && !empty($favicon)) {
			$favicon_meta = wp_check_filetype($favicon);
			if (is_array($favicon_meta) && preg_match('/^image\//i', $favicon_meta['type'])) {
				echo '<link rel="shortcut icon" type="'.$favicon_meta['type'].'" href="'.$favicon.'">';
			}
		}
?>

	<style type="text/css" data-wp="customizer">
		html {
			font-family: <?php echo $serif; ?>;
		}
		label, button, input, select, .button, .field, input[type="submit"] {
			font-family: <?php echo $sans; ?>;
		}
		::selection {
			background-color: <?php echo $normal; ?>;
		}
		a {
			color: <?php echo $normal; ?>;
			border-color: rgba(<?php echo hex2rgb($normal); ?>, 0.5);
			fill: <?php echo $normal; ?>;
		}
		a:hover, a:focus {
			color: <?php echo $hover; ?>;
			border-color: rgba(<?php echo hex2rgb($hover); ?>, 0.5);
			fill: <?php echo $hover; ?>;
		}
		.field:focus {
			border-color: <?php echo $normal; ?>;
		}
		.button, input[type="submit"] {
			color: <?php echo $normal; ?>;
			border-color: <?php echo $normal; ?>;
		}
		.button:hover, .button:focus, input[type="submit"]:hover, input[type="submit"]:focus {
			color: <?php echo $hover; ?>;
			border-color: <?php echo $hover; ?>;
		}
		.button--primary {
			background-color: <?php echo $normal; ?> !important;
		}
		.button--primary:hover, .button--primary:focus {
			background-color: <?php echo $hover; ?> !important;
		}
	</style>
<?php
		if (!empty($webfonts)) {
			echo $webfonts;
		}
	}
}

if (!function_exists('neko__sanitize_fonts')) {
	function neko__sanitize_fonts($input)
	{
		$input = str_replace(array(';', '"'), array('', '\''), $input);
		return trim($input);
	}
}

if (!function_exists('neko__customize_register')) {
	function neko__customize_register($wp_customize)
	{
		global $neko__color_link_default,
			   $neko__color_hover_default,
			   $neko__fonts_serif,
			   $neko__fonts_sans;

		if ( ! is_admin()) {
			return;
		}

		class neko__WP_Customize_Textarea_Control extends WP_Customize_Control
		{
			public $type = 'textarea';

			public function render_content()
			{
		?>
			<label>
				<span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
				<textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea($this->value()); ?></textarea>
			</label>
		<?php
			}
		}

		$wp_customize->add_setting('neko__copyright_name', array(
			'default'     => get_option('blogname'),
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'neko__copyright_name', array(
			'label'       => __('Copyright', 'neko'),
			'section'     => 'title_tagline',
			'settings'    => 'neko__copyright_name'
		)));

		// Theme Options

		$wp_customize->add_section('neko__header', array(
			'title'       => __('Header', 'neko'),
			'priority'    => 30
		));

		$wp_customize->add_setting('neko__header_fixed', array(
			'default'     => true,
			'transport'   => 'postMessage',
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_setting('neko__favicon', array(
			'transport'   => 'postMessage',
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'neko__header_fixed', array(
			'label'      => __('Fix header to top of viewport', 'neko'),
			'type'       => 'checkbox',
			'section'    => 'neko__header',
			'settings'   => 'neko__header_fixed'
		)));

		$wp_customize->add_control(new WP_Customize_Upload_Control($wp_customize, 'neko__favicon', array(
			'label'      => __('Favicon', 'neko'),
			'section'    => 'neko__header',
			'settings'   => 'neko__favicon'
		)));

		// Colours

		$wp_customize->add_section('neko__colors', array(
			'title'       => __('Colors', 'neko'),
			// 'description' => 'Theme colors.',
			'priority'    => 31
		));

		$wp_customize->add_setting('neko__color_link', array(
			'default'     => $neko__color_link_default,
			'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_hex_color',
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_setting('neko__color_hover', array(
			'default'     => $neko__color_hover_default,
			'transport'   => 'postMessage',
			'sanitize_callback' => 'sanitize_hex_color',
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'neko__color_link', array(
			'label'      => __('Link color (normal)', 'neko'),
			'section'    => 'neko__colors',
			'settings'   => 'neko__color_link',
		)));

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'neko__color_hover', array(
			'label'      => __('Link color (hover)', 'neko'),
			'section'    => 'neko__colors',
			'settings'   => 'neko__color_hover',
		)));

		// Fonts

		$wp_customize->add_section('neko__fonts', array(
			'title'       => __('Fonts', 'neko'),
			'priority'    => 32,
			'description' => __('To use a web font provider enter code including <code>&lt;script&gt;</code> tags.', 'neko')
		));

		$wp_customize->add_setting('neko__fonts_serif', array(
			'default'     => $neko__fonts_serif,
			'transport'   => 'postMessage',
			'sanitize_callback' => 'neko__sanitize_fonts',
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_setting('neko__fonts_sans', array(
			'default'     => $neko__fonts_sans,
			'transport'   => 'postMessage',
			'sanitize_callback' => 'neko__sanitize_fonts',
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_setting('neko__fonts_js', array(
			'default'     => '',
			'transport'   => 'refresh',
			'capability'  => 'edit_theme_options'
		));

		$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'neko__fonts_serif', array(
			'label'      => __('Serif fonts', 'neko'),
			'section'    => 'neko__fonts',
			'settings'   => 'neko__fonts_serif',
		)));

		$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'neko__fonts_sans', array(
			'label'      => __('Sans-serif fonts', 'neko'),
			'section'    => 'neko__fonts',
			'settings'   => 'neko__fonts_sans',
		)));

		$wp_customize->add_control(new neko__WP_Customize_Textarea_Control($wp_customize, 'neko__fonts_js', array(
			'label'      => __('Web font loader (JavaScript)', 'neko'),
			'section'    => 'neko__fonts',
			'settings'   => 'neko__fonts_js',
		)));
	}
}

?>
