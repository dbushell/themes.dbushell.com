<?php

add_action('admin_enqueue_scripts',  'neko__admin_enqueue_scripts');
add_action('add_meta_boxes',         'neko__add_meta_boxes');
add_action('save_post',              'neko__save_post');

if (!function_exists('neko__admin_enqueue_scripts')) {
	function neko__admin_enqueue_scripts()
	{
		wp_enqueue_style('wp-color-picker');
		wp_enqueue_script('wp-color-picker');

		wp_enqueue_style('neko__admin-css', get_template_directory_uri() . '/assets/css/wp-admin.css', array(), NEKO__VERSION, 'all');
		wp_enqueue_script('neko__admin-js', get_template_directory_uri() . '/assets/js/wp-admin.min.js', array('jquery'), NEKO__VERSION, true);
	}
}

if (!function_exists('neko__add_meta_boxes')) {
	function neko__add_meta_boxes($args)
	{
		remove_meta_box('pageparentdiv', 'page', 'side');
		add_meta_box('neko__banner', 'Post Header', 'neko__banner_meta_box', 'post', 'normal', 'high');
		add_meta_box('neko__banner', 'Page Header', 'neko__banner_meta_box', 'page', 'normal', 'high');

		if (count(get_page_templates())) {
			add_meta_box('neko__template', 'Page Options', 'neko__template_meta_box', 'page', 'side', 'default');
		}
	}
}

if (!function_exists('neko__template_meta_box')) {
	function neko__template_meta_box($post)
	{
		$template = !empty($post->page_template) ? $post->page_template : false;
?>
<p><strong><?php _e('Template', 'neko') ?></strong></p>
<label class="screen-reader-text" for="page_template"><?php _e('Page Template', 'neko') ?></label>
<select name="page_template" id="page_template">
<option value="default"><?php _e('Default Template', 'neko'); ?></option>
<?php page_template_dropdown($template); ?>
</select>
<?php
	}
}

if (!function_exists('neko__banner_meta_box')) {
	function neko__banner_meta_box($post)
	{
		$format = get_post_meta($post->ID, 'neko__banner_format', true);
		$pattern = get_post_meta($post->ID, 'neko__banner_pattern', true);
		$subtitle = get_post_meta($post->ID, 'neko__banner_subtitle', true);
		$subtitle_text = get_post_meta($post->ID, 'neko__banner_subtitle_text', true);
		$image_id = get_post_meta($post->ID, 'neko__banner_image_id', true);
		$bg_color = get_post_meta($post->ID, 'neko__banner_bg_color', true);
		$text_color = get_post_meta($post->ID, 'neko__banner_text_color', true);

		$image = null;
		$image_meta = null;

		if (is_numeric($image_id)) {
			$image = wp_get_attachment_image(intval($image_id), 'large');
			$image_meta = wp_get_attachment_metadata(intval($image_id));
		}
		if (empty($subtitle)) {
			$subtitle = ($post->post_type == 'page') ? 'none' : 'date';
		}
		if (empty($format)) {
			$format = 'text';
		}

		wp_nonce_field('neko__banner_meta_save', 'neko__banner_meta_nonce');
?>
		<div class="neko__mb neko__mb-banner">
			<fieldset class="neko__mb-banner__image">
				<h2><?php _e('Header Image', 'neko'); ?>
					<small class="neko__mb-banner__image_meta"><?php if ($image_meta) { echo '('.$image_meta['width'].'&times;'.$image_meta['height'].')'; } else { echo '&nbsp;'; } ?></small>
				</h2>
				<div class="neko__mb__options">
					<a href="#" class="neko__mb-banner__remove<?php if (!$image) { ?> neko__mb__link-off<?php } ?>"><?php _e('Remove', 'neko'); ?></a>
					<button type="button" class="button neko__mb-banner__add"><?php _e('Select Image', 'neko'); ?></button>
				</div>
				<div class="neko__mb__preview"><?php if ($image) { echo $image; } ?></div>

				<input type="hidden" name="neko__banner[image_id]" id="neko__mb-banner__image_id" value="<?php echo $image_id; ?>" />
			</fieldset>
			<div class="neko__mb__panel">
			<fieldset class="neko__mb-banner__subtitle">
				<h3><?php _e('Sub-Title', 'neko'); ?></h3>
				<ul>
					<li>
						<label for="neko__mb-banner__st1">
							<input type="radio" name="neko__banner[subtitle]" id="neko__mb-banner__st1" value="none" <?php checked($subtitle, 'none'); ?>>
							<?php _e('None', 'neko'); ?>
						</label>
					</li>
					<li>
						<label for="neko__mb-banner__st2">
							<input type="radio" name="neko__banner[subtitle]" id="neko__mb-banner__st2" value="date" <?php checked($subtitle, 'date'); ?>>
							<?php _e('Date', 'neko'); ?> <small>(<?php _e('published', 'neko'); ?>)</small>
						</label>
					</li>
					<li>
						<label for="neko__mb-banner__st3">
							<input type="radio" name="neko__banner[subtitle]" id="neko__mb-banner__st3" value="text" <?php checked($subtitle, 'text'); ?>>
							<?php _e('Custom', 'neko'); ?>:
						</label>
					</li>
				</ul>
				<input type="text" placeholder="<?php _e('Enter sub-title here', 'neko'); ?>&hellip;" name="neko__banner[subtitle_text]" id="neko__mb-banner__subtitle_text" value="<?php echo $subtitle_text; ?>">
			</fieldset>
			<fieldset class="neko__mb-banner__format">
				<h3><?php _e('Format', 'neko'); ?></h3>
				<ul>
					<li>
						<label for="neko__mb-banner__f1">
							<input type="radio" name="neko__banner[format]"  id="neko__mb-banner__f1" value="text" <?php checked($format, 'text'); ?>>
							<?php _e('Typographic', 'neko'); ?>
						</label>
					</li>
					<li>
						<label for="neko__mb-banner__f2">
							<input type="radio" name="neko__banner[format]"  id="neko__mb-banner__f2" value="half" <?php checked($format, 'half'); ?>>
							<?php _e('Banner', 'neko'); ?> <small>(<?php _e('half page image', 'neko'); ?>)</small>
						</label>
					</li>
					<li>
						<label for="neko__mb-banner__f3">
							<input type="radio" name="neko__banner[format]"  id="neko__mb-banner__f3" value="cover" <?php checked($format, 'cover'); ?>>
							<?php _e('Cover', 'neko'); ?> <small>(<?php _e('full page image', 'neko'); ?>)</small>
						</label>
					</li>
				</ul>
				<hr>
				<label for="neko__mb-banner__pattern">
					<input type="checkbox" name="neko__banner[pattern]" id="neko__mb-banner__pattern"  <?php checked($pattern, 'on'); ?>>
					<?php _e('Pattern', 'neko'); ?> <small>(<?php _e('tile image', 'neko'); ?>)</small>
				</label>
			</fieldset>
			<fieldset class="neko__mb-banner__colors">
				<h3><?php _e('Colors', 'neko'); ?></h3>
				<ul>
					<li>
						<label for="neko__mb-banner__bg_color"><?php _e('Background color', 'neko'); ?>:</label>
						<input type="text" name="neko__banner[bg_color]" id="neko__mb-banner__bg_color" value="<?php echo $bg_color; ?>">
					</li>
					<li>
						<label for="neko__mb-banner__text_color"><?php _e('Text color', 'neko'); ?>:</label>
						<input type="text" name="neko__banner[text_color]" id="neko__mb-banner__text_color" value="<?php echo $text_color; ?>">
					</li>
				</li>
				<p class="description"><?php _e('Enter hex color values or leave blank for defaults.', 'neko'); ?></p>
			</fieldset>
			</div>
		</div>
<?php
	}
}

if (!function_exists('neko__save_post')) {
	function neko__save_post($post_id)
	{
		if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return $post_id;
		}
		if (!isset($_POST['neko__banner_meta_nonce']) || ! wp_verify_nonce($_POST['neko__banner_meta_nonce'], 'neko__banner_meta_save')) {
			return $post_id;
		}
		if ($_POST['post_type'] == 'page') {
			if (!current_user_can('edit_page', $post_id)) {
				return $post_id;
			}
		} else {
			if (!current_user_can('edit_post', $post_id)) {
				return $post_id;
			}
		}

		$data = $_POST['neko__banner'];
		if (!isset($data)) {
			return;
		}
		if (isset($data['format'])) {
			update_post_meta($post_id, 'neko__banner_format', $data['format']);
		}
		update_post_meta($post_id, 'neko__banner_pattern', isset($data['pattern']) ? 'on' : '');

		if (isset($data['subtitle'])) {
			update_post_meta($post_id, 'neko__banner_subtitle', $data['subtitle']);
		}

		$image_id = is_numeric($data['image_id']) ? intval($data['image_id']) : '';
		update_post_meta($post_id, 'neko__banner_image_id', $image_id);

		$bg_color = preg_match('/^#[0-9a-f]{3,6}$/i', $data['bg_color']) ? $data['bg_color'] : '';
		update_post_meta($post_id, 'neko__banner_bg_color', $bg_color);

		$text_color = preg_match('/^#[0-9a-f]{3,6}$/i', $data['text_color']) ? $data['text_color'] : '';
		update_post_meta($post_id, 'neko__banner_text_color', $text_color);

		$subtitle_text = isset($data['subtitle_text']) ? $data['subtitle_text'] : '';
		update_post_meta($post_id, 'neko__banner_subtitle_text', esc_attr(strip_tags($subtitle_text)));
	}
}

?>
