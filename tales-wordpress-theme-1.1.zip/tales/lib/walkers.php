<?php

class neko__Walker_Nav extends Walker_Nav_Menu
{
	protected $list_class = 'nav__list';
	protected $item_class = 'nav__item';
	protected $link_class = 'nav__link';

	static function fallback($args)
	{
		$list_class = $args['walker']->list_class;
		$item_class = $args['walker']->item_class;
		$link_class = $args['walker']->link_class;
?>
			<ul class="<?php echo $list_class; ?>">
				<li class="<?php echo $item_class; ?>">
					<a class="<?php echo $link_class; ?>" href="<?php echo home_url(); ?>"><?php bloginfo('name', 'display'); ?></a>
				</li>
			</ul>
<?php
	}

	function start_lvl(&$output, $depth = 0, $args = array())
	{
		$output .= '<ul class="'.$this->list_class.'">';
	}

	function end_lvl(&$output, $depth = 0, $args = array())
	{
		$output .= '</ul>';
	}

	function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0)
	{
		$item_classes = $this->item_class;

		if (!empty($item_classes)) {
			if (array_key_exists('neko__root_object_id', $args) && $args->neko__root_object_id == $item->object_id) {
				$item_classes .= " {$this->item_class}--root";
			}
			if ($item->current) {
				$item_classes .= " {$this->item_class}--active";
			}
			if ($args->depth && $depth < $args->depth - 1) {
				if (in_array('menu-item-has-children', $item->classes)) {
					$item_classes .= " {$this->item_class}--parent";
				}
			}
			$output .= '<li class="'.$item_classes.'">';
		} else {
			$output .= '<li>';
		}

		$atts['class']  = isset($args->neko__link_class) ? $args->neko__link_class : $this->link_class;
		$atts['title']  = ! empty($item->attr_title) ? $item->attr_title : '';
		$atts['target'] = ! empty($item->target)     ? $item->target     : '';
		$atts['rel']    = ! empty($item->xfn)        ? $item->xfn        : '';
		$atts['href']   = ! empty($item->url)        ? $item->url        : '';

		$atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args);

		$attributes = '';
		foreach ($atts as $attr => $value) {
			if (!empty($value)) {
				$value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		$item_output = $args->before;
		$item_output .= '<a'. $attributes .'>';
		$item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
		$item_output .= '</a>';
		$item_output .= $args->after;

		$output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
	}

	function end_el(&$output, $item, $depth = 0, $args = array(), $id = 0)
	{
		$output .= '</li>';
	}
}

class neko__Walker_Nav_Basic extends neko__Walker_Nav
{
	protected $item_class = '';
	protected $link_class = '';

	static function fallback($args)
	{
		return;
	}
}

class neko__Walker_Nav_Section extends neko__Walker_Nav
{
	protected $list_class = 'menu__list';
	protected $item_class = 'menu__item';
	protected $link_class = 'menu__link';

	function walk($elements, $max_depth) {

		$args = array_slice(func_get_args(), 2);
		$output = '';

		if ($max_depth < -1) //invalid parameter
			return $output;

		if (empty($elements)) //nothing to walk
			return $output;

		$id_field = $this->db_fields['id'];
		$parent_field = $this->db_fields['parent'];

		// // flat display
		// if ( -1 == $max_depth ) {
		//     $empty_array = array();
		//     foreach ( $elements as $e )
		//         $this->display_element( $e, $empty_array, 1, 0, $args, $output );
		//     return $output;
		// }

		/*
		 * Need to display in hierarchical order.
		 * Separate elements into two buckets: top level and children elements.
		 * Children_elements is two dimensional array, eg.
		 * Children_elements[10][] contains all sub-elements whose parent is 10.
		 */
		$top_level_elements = array();
		$children_elements  = array();
		foreach ( $elements as $e) {
			if ( 0 == $e->$parent_field )
				$top_level_elements[] = $e;
			else
				$children_elements[ $e->$parent_field ][] = $e;
		}

		/*
		 * When none of the elements is top level.
		 * Assume the first one must be root of the sub elements.
		 */
		if ( empty($top_level_elements) ) {

			$first = array_slice( $elements, 0, 1 );
			$root = $first[0];

			$top_level_elements = array();
			$children_elements  = array();
			foreach ( $elements as $e) {
				if ( $root->$parent_field == $e->$parent_field )
					$top_level_elements[] = $e;
				else
					$children_elements[ $e->$parent_field ][] = $e;
			}
		}

		// foreach ( $top_level_elements as $e )
		//     $this->display_element( $e, $children_elements, $max_depth, 0, $args, $output );

		$classes = array('current-menu-item', 'current-menu-parent', 'current-menu-ancestor');
		foreach ($top_level_elements as $e) {
			$arr = array_intersect($classes, $e->classes);
			if (!empty($arr)) {
				$this->display_element($e, $children_elements, $max_depth, 0, $args, $output);
			}
		}
		return $output;

		/*
		 * If we are displaying all levels, and remaining children_elements is not empty,
		 * then we got orphans, which should be displayed regardless.
		 */
		// if ( ( $max_depth == 0 ) && count( $children_elements ) > 0 ) {
		//     $empty_array = array();
		//     foreach ( $children_elements as $orphans )
		//         foreach( $orphans as $op )
		//             $this->display_element( $op, $empty_array, 1, 0, $args, $output );
		//  }

		 return $output;
	}
}

?>
