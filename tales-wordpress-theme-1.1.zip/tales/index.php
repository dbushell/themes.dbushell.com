<?php get_template_part("header"); ?>

<main class="main" id="main" role="main">

<?php get_template_part('partials/banner'); ?>

	<div class="block archives">
		<div class="block__align">

<?php
if (is_search() || isset($_GET['s']) || is_404()) {
?>
			<form class="form form--single form--search" method="get" action="<?php echo home_url( '/' ); ?>" role="search">
				<ul class="form__list">
					<li class="form__item">
						<label for="form-search__query"><?php _e('Search', 'neko'); ?></label>
						<input type="search" name="s" value="<?php the_search_query(); ?>" class="field" id="form-search__query" placeholder="<?php _e('Search', 'neko'); ?>&hellip;">
					</li>
					<li class="form__item">
						<button type="submit" class="button"><?php _e('Search', 'neko'); ?></button>
					</li>
				</ul>
			</form>
<?php
}
?>
<?php
if(have_posts()) {
	while (have_posts()) {
		the_post();
		$title = get_the_title();
		if (!strlen($title)) {
			$title = get_the_date(get_option('date_format'));
		}
		$excerpt = get_the_excerpt();
		if (!strlen($excerpt)) {
			$excerpt = '&nbsp;';
		}
		$post_class = get_post_class();
?>
			<article class="archives__post <?php echo implode($post_class, ' '); ?>">
				<?php if (is_sticky()) { ?>
				<svg class="svg--icon archives__icon" viewBox="0 0 28 28"><use xlink:href="#svg--pin"></use></svg>
				<?php } ?>
				<h3 class="archives__title"><a href="<?php the_permalink(); ?>"><?php echo $title; ?></a></h3>
				<p class="p--date archives__date"><time datetime="<?php echo get_the_date('c') ?>"><?php echo get_the_date('M j, Y'); ?></time></p>
				<p class="archives__excerpt"><?php echo $excerpt; ?></p>
				<hr>
			</article>
<?php
	}
}
?>

<?php get_template_part('partials/pagination'); ?>

		</div>
	</div>

</main>
<!--/#main-->

<?php get_template_part("footer"); ?>
