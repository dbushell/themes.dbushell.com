<?php

define('NEKO', true);
define('NEKO__VERSION', 1.0);

add_action('wp_enqueue_scripts',    'neko__wp_enqueue_scripts');
add_action('after_setup_theme',     'neko__after_setup_theme');
add_filter('upload_mimes',          'neko__upload_mimes');
add_filter('mce_buttons_2',         'neko__mce_buttons_2');
add_filter('tiny_mce_before_init',  'neko__tiny_mce_before_init');
add_filter('the_password_form',     'neko__the_password_form');
add_shortcode('wp_caption',         'neko__caption');
add_shortcode('caption',            'neko__caption');

require_once('lib/helpers.php');
require_once('lib/walkers.php');
require_once('lib/customizer.php');

if (is_admin()) {
	require_once('lib/admin.php');
}

if (!function_exists('neko__wp_enqueue_scripts')) {
	function neko__wp_enqueue_scripts()
	{
		if(is_admin()) {
			return;
		}
		/**
		 *
		 *  The main stylesheet is loaded in partials/head.php with conditional comments
		 *  ( see: http://codex.wordpress.org/Conditional_Comment_CSS )
		 *  this allows old IE 7-8 to get a non-responsive version + fixes
		 *
		 *  If you're not running WordPress behind a cache, you can remove those lines
		 *  and include CSS with `wp_enqueue_style` below
		 *
		 */

		// global $is_IE;
		// wp_enqueue_style('neko__css', get_template_directory_uri() . '/assets/css/' . ( $is_IE ? 'oldie' : 'style' ) . '.css', array(), NEKO__VERSION, 'all');

		/**
		 *
		 *  For better performance load jQuery at the end of the page
		 *
		 *  1. Download the latest version of jQuery into /assets/js/
		 *  2. Amend and uncomment the lines below
		 *
		 */

		// wp_deregister_script('jquery');
		// wp_register_script('jquery', (get_template_directory_uri().'/assets/js/jquery-1.11.0.min.js'), false, '1.11.0', true);
		// wp_enqueue_script('jquery');

		wp_enqueue_script('neko__loadrunner', get_template_directory_uri().'/assets/js/loadrunner.min.js', array(), NEKO__VERSION, false);
		wp_enqueue_script('neko__main', get_template_directory_uri().'/assets/js/main.min.js', array('jquery'), NEKO__VERSION, true);
	}
}

if(!function_exists('neko__after_setup_theme')) {
	function neko__after_setup_theme()
	{
		add_editor_style('assets/css/editor.css');

		load_theme_textdomain('neko', get_template_directory() . '/languages');

		register_nav_menu('primary', 'Primary Menu');
		register_nav_menu('footer', 'Footer Menu');

		add_theme_support('automatic-feed-links');

		add_image_size('neko__banner_s', 480,  9999);
		add_image_size('neko__banner_m', 800,  9999);
		add_image_size('neko__banner_l', 1120, 9999);
		add_image_size('neko__banner_x', 1440, 9999);

		if (!isset($content_width)) {
			$content_width = 640;
		}

		remove_action('wp_head', 'rsd_link');
		remove_action('wp_head', 'wlwmanifest_link');
		remove_action('wp_head', 'wp_generator');
	}
}

if (!function_exists('neko__upload_mimes')) {
	function neko__upload_mimes($mimes = array())
	{
		$mimes['svg'] = 'image/svg+xml';
		$mimes['ico'] = 'image/x-icon';
		return $mimes;
	}
}

if(!function_exists('neko__comment')) {
	function neko__comment($comment, $args, $depth)
	{
		$comment_id = $comment->comment_ID;
		the_comment($comment_id);

		preg_match('/src=\'(.*?)\'/i', get_avatar(get_comment_author_email($comment_id), 100), $avatar);
		$avatar = $avatar[1];

		$comment_class = get_comment_class($comment_id);
		if (!in_array('comment', $comment_class)) {
			$comment_class[] = 'comment';
		}
?>
				<li>
				<article class="<?php echo implode($comment_class, ' '); ?>" id="<?php comment_ID(); ?>">
					<?php if (!in_array($comment->comment_type, array('pingback', 'trackback'))) { ?>
					<div class="comment__avatar">
						<div style="background-image: url('<?php echo esc_url($avatar); ?>');"></div>
					</div>
					<?php } ?>
					<div class="comment__body">
						<?php
						$comment_url = get_comment_author_url($comment_id);
						if (empty($comment_url)) {
						?>
						<h3 class="comment__author"><?php comment_author(); ?></h3>
						<?php } else { ?>
						<h3 class="comment__author"><a rel="nofollow" href="<?php echo $comment_url; ?>"><?php comment_author(); ?></a></h3>
						<?php } ?>
						<p class="p--small p--date comment__date"><?php comment_date(get_option('date_format')); ?></p>

						<?php if ($comment->comment_approved == '0') { ?>
							<p class="p--small"><em class="mark"><?php _e('Your comment is awaiting moderation', 'neko'); ?>.</em></p>
						<?php } ?>

						<?php comment_text(); ?>

						<p class="p--small">
						<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
						<?php edit_comment_link('('.__('Edit', 'neko').')', '', ''); ?>
						</p>
						<hr>
					</div>
				</article>
				<!--/.comment-->
<?php
	}
}

function neko__caption($attr, $content = null)
{
	if (!isset($attr['caption'])) {
		if (preg_match( '#((?:<a [^>]+>\s*)?<img [^>]+>(?:\s*</a>)?)(.*)#is', $content, $matches)) {
			$attr['caption'] = trim($matches[2]);
		}
	}
	if (!isset($attr['alt'])) {
		if (preg_match( '#alt="([^"]*)"#is', $content, $matches)) {
			$attr['alt'] = trim($matches[1]);
		}
	}
	if (!isset($attr['url'])) {
		if (preg_match( '#href="([^"]*)"#is', $content, $matches)) {
			$attr['url'] = trim($matches[1]);
		}
	}
	if (!isset($attr['src'])) {
		if (preg_match( '#src="([^"]*)"#is', $content, $matches)) {
			$attr['src'] = trim($matches[1]);
		}
	}

	$attr = shortcode_atts(array(
		'id'      => '',
		'align'   => '',
		'width'   => '',
		'caption' => '',
		'src'     => '',
		'alt'     => '',
		'url'     => ''
	), $attr, 'caption');

	if ($attr['align'] == 'aligncenter') {
		$html = '<figure class="figure--center">';
	} else {
		$html = '<figure>';
	}
	$html .= '<img src="'.$attr['src'].'" alt="'.$attr['alt'].'">';
	if (!empty($attr['caption'])) {
		if (!empty($attr['url'])) {
			$html .= '<figcaption><a rel="nofollow" target="_blank" href="'.$attr['url'].'">'.$attr['caption'].'</a></figcaption>';
		} else {
			$html .= '<figcaption>'.$attr['caption'].'</figcaption>';
		}
	}
	$html .= '</figure>';

	return $html;
}

if (!function_exists('neko__mce_buttons_2')) {
	function neko__mce_buttons_2($buttons)
	{
		array_unshift($buttons, 'styleselect');

		$remove = array('indent', 'outdent');

		return array_diff($buttons, $remove);
	}
}

if (!function_exists('neko__tiny_mce_before_init')) {
	function neko__tiny_mce_before_init($init_array)
	{
		$style_formats = array(
			array(
				'title'   => __('Large Paragraph', 'neko'),
				'block'   => 'p',
				'classes' => 'p--large',
				'wrapper' => false
			),
			array(
				'title'   => __('Small Paragraph', 'neko'),
				'block'   => 'p',
				'classes' => 'p--small',
				'wrapper' => false
			),
			array(
				'title'   => __('Highlight', 'neko'),
				'inline'  => 'mark'
			),
			array(
				'title'   => __('Inline Quote', 'neko'),
				'inline'  => 'q'
			),
			array(
				'title'   => __('Blockquote', 'neko'),
				'block'   => 'blockquote',
				'wrapper' => true
			),
			array(
				'title'   => __('Blockquote Citation', 'neko'),
				'inline'   => 'cite'
			),
			array(
				'title'   => __('Large Quote', 'neko'),
				'block'   => 'blockquote',
				'classes' => 'quote--large',
				'wrapper' => true
			),
			array(
				'title'   => __('Pull Quote', 'neko'),
				'block'   => 'blockquote',
				'classes' => 'quote--pull',
				'wrapper' => true
			)
		);
		$init_array['style_formats'] = json_encode($style_formats);
		return $init_array;
	}
}

if (!function_exists('neko__the_password_form')) {
	function neko__the_password_form($html)
	{
		global $post;
		$label   = 'pwbox-' . ( empty($post->ID) ? rand() : $post->ID );
		$output  = '<p>' . __('This content is password protected. To view it please enter your password below:', 'neko') . '</p>';
		$output .= '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" class="form form--inline" method="post">';
		$output .= '<ul class="form__list">';
		$output .= '<li class="form__item"><label for="' . $label . '">' . __( 'Password:', 'neko') . '</label>';
		$output .= '<input class="field" name="post_password" id="' . $label . '" type="password" /></li>';
		$output .= '<li class="form__item"><input type="submit" name="Submit" value="' . esc_attr__( 'Submit' ) . '" /></li>';
		$output .= '</ul></form>';
		return $output;
	}
}

?>
