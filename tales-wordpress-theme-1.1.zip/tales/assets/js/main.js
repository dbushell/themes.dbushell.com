/*!
 *
 *  Copyright (c) David Bushell | @dbushell | http://dbushell.com/
 *
 */
(function(window, document, $, undefined)
{
	'use strict';

	window.Tales = (function()
	{

		var _init = 0, app = { };

		var doc  = $(document.documentElement),
			win  = $(window);

		app.init = function()
		{
			if (_init++) {
				return;
			}

			var scroll_top = [0, 0],
				win_width = 0,
				win_height = 0;

			var $header = $('#header'),
				header_height = $header.outerHeight();

			var $wrapper  = $('.wrapper'),
				$main     = $('.main'),
				$covers   = $('.banner--half, .banner--cover').first(),
				$search   = $('.search-modal'),
				$search__criteria = $('.search-modal__criteria');

			$('.prose > table').wrap('<div class="table-container"/>');

			var hash = window.location.hash || "";
			if (hash.length > 1) {
				$.each(hash.substring(1).split(','), function(k, v) {
					doc.addClass('js--' + v);
					if (v === 'nav') {
						app.isNav = true;
					}
					if (v === 'search') {
						app.isSearch = true;
						setTimeout(function() { $search__criteria.focus(); }, 1);
					}
				});
			}

			var $menus = $('.menu--collapsed');
			$menus.on('click', '.menu__toggle', function(e)
			{
				e.preventDefault();
				$(e.delegateTarget).toggleClass('menu--collapsed');
				return false;
			});

			app.navOpen = function(e)
			{
				if (e) e.preventDefault();
				doc.addClass('js--nav');
				app.isNav = true;
				return false;
			};

			app.navClose = function(e)
			{
				if (e) e.preventDefault();
				doc.removeClass('js--nav');
				app.isNav = false;
				return false;
			};

			app.searchOpen = function(e)
			{
				if (e) e.preventDefault();
				if (app.isSearch) {
					doc.removeClass('js--search');
					app.isSearch = false;
				} else {
					doc.addClass('js--search');
					setTimeout(function() { $search__criteria.focus(); }, 1);
					app.isSearch = true;
				}
				return false;
			};

			app.searchClose = function(e)
			{
				if (e) e.preventDefault();
				doc.removeClass('js--search');
				app.isSearch = false;
				return false;
			};


				$('.header__nav').on('click', app.navOpen);
				$('.nav__return').on('click', app.navClose);

				$wrapper.on('click', function(e)
				{
					if (app.isNav) {
						app.navClose();
					}
				});

			if (window.Modernizr.csstransforms3d)
			{
				$('.header__search').on('click', app.searchOpen);

				$search.on('click', function(e)
				{
					if (!$(e.target).hasClass('field')) {
						app.searchClose();
					}
				});
			}

			win.on('keydown', function(e)
			{
				var code = e.keyCode || e.which;
				if (code === 27) {
					if (app.isSearch) {
						app.searchClose();
					}
					if (app.isNav) {
						app.navClose();
					}
				}
			});

			if ($covers.filter('.banner--half').length) {
				var cover_height = $covers.outerHeight();
			}

			$('a[href][data-scroll="true"]').on('click', function(e)
			{
				var id = $(this).attr('href');
				if (!id || id.indexOf('#') !== 0) {
					return;
				}
				var el = $(id);
				if (!el.length) {
					return;
				}
				e.preventDefault();
				$('html,body').animate({ scrollTop: el.offset().top });
			});

			app.onResize = function(e)
			{
				var ww = win.width(),
					wh = win.height();
				if (ww === win_width && Math.abs(win_height - wh) < 100) {
					return false;
				}
				win_width = ww;
				win_height = wh;
				$wrapper.css({ 'min-height': win_height });

				if (cover_height) {
					cover_height = $covers.outerHeight();
				}
				$covers.filter('.banner--cover').css({ 'min-height': win_height });

				app.onScroll();
			};

			app.isHeaderFixed = $header.hasClass('header--fixed');
			app.isBanner = $covers.length;

			var scroll_timeout;

			app.onScroll = function(e)
			{
				scroll_top[0] = scroll_top[1];
				scroll_top[1] = win.scrollTop();

				if ( ! app.isHeaderFixed) {
					scroll_top[1] = 0;
				}

				if (app.isBanner) {
					if (scroll_top[1] < (cover_height || win_height) - header_height) {
						$header.addClass('js--cover');
					} else {
						$header.removeClass('js--cover');
					}
				}

				if (scroll_top[1] > header_height) {
					if (scroll_top[1] > scroll_top[0]) {
						$header.addClass('js--fixed js--inactive');
					} else {
						$header.removeClass('js--inactive');
					}
				} else {
					$header.removeClass('js--fixed');
				}

				clearTimeout(scroll_timeout);
				if (e) {
					scroll_timeout = setTimeout(function() {
						if (win.scrollTop() <= 0) {
							$header.removeClass('js--fixed js--inactive');
						}
					}, 300);
				}
			};

			if (app.isHeaderFixed) {
				$(window).on('resize scroll orientationchange', $.throttle(50, app.onScroll));
			}
			$(window).on('resize orientationchange', $.throttle(10, app.onResize));

			app.onResize();
			app.onScroll();

			doc.addClass('js--ready');

			$main.fitVids();
		};

		return app;

	})();

	$(document).ready(function() {
		window.Tales.init();
	});

})(window, window.document, window.jQuery);

/*
 * jQuery throttle / debounce - v1.1 - 3/7/2010
 * http://benalman.com/projects/jquery-throttle-debounce-plugin/
 *
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function(b,c){var $=b.jQuery||b.Cowboy||(b.Cowboy={}),a;$.throttle=a=function(e,f,j,i){var h,d=0;if(typeof f!=="boolean"){i=j;j=f;f=c}function g(){var o=this,m=+new Date()-d,n=arguments;function l(){d=+new Date();j.apply(o,n)}function k(){h=c}if(i&&!h){l()}h&&clearTimeout(h);if(i===c&&m>e){l()}else{if(f!==true){h=setTimeout(i?k:l,i===c?e-m:e)}}}if($.guid){g.guid=j.guid=j.guid||$.guid++}return g};$.debounce=function(d,e,f){return f===c?a(d,e,false):a(d,f,e!==false)}})(this);

/*global jQuery */
/*jshint multistr:true browser:true */
/*!
* FitVids 1.0.3
*
* Copyright 2013, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
* Credit to Thierry Koblentz - http://www.alistapart.com/articles/creating-intrinsic-ratios-for-video/
* Released under the WTFPL license - http://sam.zoy.org/wtfpl/
*
* Date: Thu Sept 01 18:00:00 2011 -0500
*/

(function( $ ){

  "use strict";

  $.fn.fitVids = function( options ) {
	var settings = {
	  customSelector: null
	};

	if(!document.getElementById('fit-vids-style')) {

	  var div = document.createElement('div'),
		  ref = document.getElementsByTagName('base')[0] || document.getElementsByTagName('script')[0],
		  cssStyles = '&shy;<style>.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}</style>';

	  div.className = 'fit-vids-style';
	  div.id = 'fit-vids-style';
	  div.style.display = 'none';
	  div.innerHTML = cssStyles;

	  ref.parentNode.insertBefore(div,ref);

	}

	if ( options ) {
	  $.extend( settings, options );
	}

	return this.each(function(){
	  var selectors = [
		"iframe[src*='player.vimeo.com']",
		"iframe[src*='youtube.com']",
		"iframe[src*='youtube-nocookie.com']",
		"iframe[src*='kickstarter.com'][src*='video.html']",
		"object",
		"embed"
	  ];

	  if (settings.customSelector) {
		selectors.push(settings.customSelector);
	  }

	  var $allVideos = $(this).find(selectors.join(','));
	  $allVideos = $allVideos.not("object object"); // SwfObj conflict patch

	  $allVideos.each(function(){
		var $this = $(this);
		if (this.tagName.toLowerCase() === 'embed' && $this.parent('object').length || $this.parent('.fluid-width-video-wrapper').length) { return; }
		var height = ( this.tagName.toLowerCase() === 'object' || ($this.attr('height') && !isNaN(parseInt($this.attr('height'), 10))) ) ? parseInt($this.attr('height'), 10) : $this.height(),
			width = !isNaN(parseInt($this.attr('width'), 10)) ? parseInt($this.attr('width'), 10) : $this.width(),
			aspectRatio = height / width;
		if(!$this.attr('id')){
		  var videoID = 'fitvid' + Math.floor(Math.random()*999999);
		  $this.attr('id', videoID);
		}
		$this.wrap('<div class="fluid-width-video-wrapper"></div>').parent('.fluid-width-video-wrapper').css('padding-top', (aspectRatio * 100)+"%");
		$this.removeAttr('height').removeAttr('width');
	  });
	});
  };
// Works with either jQuery or Zepto
})( window.jQuery || window.Zepto );
