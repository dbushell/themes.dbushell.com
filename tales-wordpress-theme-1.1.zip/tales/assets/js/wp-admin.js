
jQuery(function($)
{
    // $('#titlediv').after($('#postimagediv'));

    // Post Banner

    var $banner__image_id   = $('#neko__mb-banner__image_id');
    var $banner__image_meta = $('.neko__mb-banner__image_meta');
    var $banner__preview    = $('.neko__mb-banner__image .neko__mb__preview');
    var $banner__remove     = $('.neko__mb-banner__remove');
    var $banner__add        = $('.neko__mb-banner__add');

    var $banner_format        = $('input[name="neko__banner[format]"]');
    var $banner_subtitle      = $('input[name="neko__banner[subtitle]"]');
    var $banner_subtitle_text = $('#neko__mb-banner__subtitle_text');
    var $banner_pattern       = $('#neko__mb-banner__pattern');

    var bgColorChange = function(e)
    {
        var input = $(e.target);
        setTimeout(function()
        {
            if (input.val() && $banner_format.filter(':checked').val() === 'text') {
                $banner_format.filter('[value="half"]').trigger('click');
            }
        }, 1);
    };

    if (typeof $.fn.wpColorPicker) {
        $('#neko__mb-banner__bg_color').wpColorPicker({ change: bgColorChange });
        $('#neko__mb-banner__text_color').wpColorPicker();
    }

    $banner__add.on('click', function(e)
    {
        e.preventDefault();
        wp.media.editor.send.attachment = function(props, attachment)
        {
            $banner__image_id.val(attachment.id);
            $banner__preview.empty().append($('<img src="' + attachment.url + '">'));
            $banner__image_meta.html('(' + attachment.width + '&times;' + attachment.height+ ')') ;
            $banner__remove.removeClass('neko__mb__link-off');

            if ($banner_format.filter(':checked').val() === 'text') {
                $banner_format.filter('[value="half"]').trigger('click');
            }
        };
        wp.media.editor.open(this);
        return false;
    });

    $banner__remove.on('click', function(e)
    {
        e.preventDefault();
        $banner__image_id.val('');
        $banner__remove.addClass('neko__mb__link-off');
        $banner__image_meta.html('&nbsp;');
        // $banner__image_meta.text($banner__image_meta.data('default'));
        $banner__preview.html('');

        if ($banner_format.filter(':checked').val() !== 'text') {
            $banner_format.filter('[value="text"]').trigger('click');
            if ($banner_pattern.is(':checked')) {
                $banner_pattern.trigger('click');
            }
        }
        return false;
    });

    var update_subtitle = function(focus)
    {
        var value = $banner_subtitle.filter(':checked').val();
        if (value === 'text') {
            $banner_subtitle_text.prop('disabled', false);
            if (focus) {
                $banner_subtitle_text.focus();
            }
        } else {
            $banner_subtitle_text.prop('disabled', true);
        }
    };

    update_subtitle();

    $banner_subtitle.on('change', function(e) {
        update_subtitle(true);
    });
});
