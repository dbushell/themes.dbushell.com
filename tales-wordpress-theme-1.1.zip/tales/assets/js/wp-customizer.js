(function($)
{
    function hex2rgb(hex)
    {
        var rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return rgb ? parseInt(rgb[1], 16) + ',' + parseInt(rgb[2], 16) + ',' + parseInt(rgb[3], 16) : hex;
    }

    var styles = null,
        stylesheets = document.styleSheets;

    for (var i = 0; i < stylesheets.length; i++)
    {
        if (stylesheets[i].ownerNode && stylesheets[i].ownerNode.nodeType === 1) {
            if ($(stylesheets[i].ownerNode).data('wp') === 'customizer') {
                styles = stylesheets[i];
                break;
            }
        }
    }
    if (!styles || !styles.rules) {
        return;
    }

    function find_rule(selector)
    {
        var len = styles.rules.length;
        for (var i = 0; i < len; i++) {
            if (styles.rules[i].selectorText === selector) {
                return styles.rules[i];
            }
        }
    }

    wp.customize('neko__fonts_serif', function(value) {
        value.bind(function(val)
        {
            var rule = find_rule('html');
            if (rule) {
                rule.style.fontFamily = val;
            }
        });
    });

    wp.customize('neko__fonts_sans', function(value) {
        value.bind(function(val)
        {
            var rule = find_rule('label, button, input, select, .button, .field, input[type="submit"]');
            if (rule) {
                rule.style.fontFamily = val;
            }
        });
    });

    wp.customize('neko__header_fixed', function(value) {
        value.bind(function(val)
        {
            if (val) {
                $('#header').addClass('header--fixed');
            } else {
                $('#header').removeClass('header--fixed');
            }
        });
    });

    wp.customize('neko__color_link', function(value) {
        value.bind(function(val)
        {
            var rule = find_rule('a');
            if (rule) {
                rule.style.fill = val;
                rule.style.color = val;
                rule.style.borderColor = 'rgba(' + hex2rgb(val) + ', 0.5)';
            }
            rule = find_rule('::selection');
            if (rule) {
                rule.style.backgroundColor = val;
            }
            rule = find_rule('.field:focus');
            if (rule) {
                rule.style.borderColor = val;
            }
            rule = find_rule('.button, input[type="submit"]');
            if (rule) {
                rule.style.color = val;
                rule.style.borderColor = val;
            }
            rule = find_rule('.button--primary');
            if (rule) {
                rule.style.backgroundColor = val;
            }
        });
    });

    wp.customize('neko__color_hover', function(value) {
        value.bind(function(val)
        {
            var rule = find_rule('a:hover, a:focus');
            if (val) {
                rule.style.fill = val;
                rule.style.color = val;
                rule.style.borderColor = 'rgba(' + hex2rgb(val) + ', 0.5)';
            }
            rule = find_rule('.button:hover, .button:focus, input[type="submit"]:hover, input[type="submit"]:focus');
            if (rule) {
                rule.style.color = val;
                rule.style.borderColor = val;
            }
            rule = find_rule('.button--primary:hover, .button--primary:focus');
            if (rule) {
                rule.style.backgroundColor = val;
            }
        });
    });

})(jQuery);
