
	<footer class="block footer" role="contentinfo">

		<div class="block__align">
			<ul class="footer__nav">
<?php

wp_nav_menu(array(
	'theme_location'    => 'footer',
	'depth'             => 1,
	'container'         => false,
	'items_wrap'        => '%3$s',
	'neko__link_class'  => 'footer__link',
	'fallback_cb'       => 'neko__Walker_Nav_Basic::fallback',
	'walker'            => new neko__Walker_Nav_Basic())
);

?>
			</ul>
			<?php get_template_part('partials/copyright'); ?>
		</div>
	</footer>
	<!--/.footer-->

</div>
<!--/.wrapper-->

<?php get_template_part('partials/search'); ?>
<?php get_template_part('partials/nav'); ?>
<?php get_template_part('partials/svg'); ?>

<?php wp_footer(); ?>
</body>
</html>
