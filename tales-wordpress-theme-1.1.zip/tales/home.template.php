<?php
/*
Template Name: Home
*/
?>
<?php get_template_part("header"); ?>

<main class="main" id="main" role="main">

<?php get_template_part('partials/banner'); ?>


	<div class="block sidebar" id="content">
		<div class="block__align">
<?php
rewind_posts();
if (have_posts()) {
	while (have_posts()) {
		the_post();
?>
			<div class="block__body prose">
				<?php the_content(); ?>
			</div>
<?php
	}
}
?>
			<aside class="block__aside">
				<h2><?php _e('Latest Articles', 'neko'); ?></h2>
				<?php

				$articles = get_posts($args = array(
					'posts_per_page'   => 3,
					'offset'           => 0,
					'orderby'          => 'post_date',
					'order'            => 'DESC',
					'post_type'        => 'post',
					'post_status'      => 'publish',
					'suppress_filters' => true
				));

				if (count($articles)) {
				?>
				<ul class="ul--latest">
				<?php
					global $post;
					foreach ($articles as $post) {
						setup_postdata($post);
				?>
					<li>
						<h3 class="h4"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<p class="p--date"><time datetime="<?php echo get_the_date('c') ?>"><?php echo get_the_date('M j, Y'); ?></time></p>
					</li>
				<?php } ?>
				</ul>
				<?php } ?>
				<p>
					<a class="archives__newer" href="<?php echo get_permalink(get_option('page_for_posts')); ?>">
						<span><?php _e('More', 'neko'); ?></span>
						<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--arrow--right"></use></svg>
					</a>
				</p>
			</aside>

		</div>
	</div>


</main>
<!--/#main-->

<?php get_template_part("footer"); ?>
