<!DOCTYPE html>
<!--[if IE 7]> <html <?php language_attributes(); ?> class="lt-ie9 lt-ie8 no-js"> <![endif]-->
<!--[if IE 8]> <html <?php language_attributes(); ?> class="lt-ie9 no-js"> <![endif]-->
<!--[if gt IE 8]><!--> <html <?php language_attributes(); ?> class="no-js"> <!--<![endif]-->
<head>
<?php get_template_part('partials/head'); ?>
</head>
<body <?php body_class(); ?> id="top">

<div class="wrapper">

<?php
$header_class = 'block header';
if (get_theme_mod('neko__header_fixed', true)) {
	$header_class .= ' header--fixed';
}
?>
	<header class="<?php echo $header_class; ?>" id="header" role="banner">
		<div class="block__align">
			<h1 class="header__title">
				<a href="<?php echo home_url(); ?>" title="<?php echo esc_attr(get_bloginfo('name', 'display')); ?>" rel="home"><?php bloginfo('name', 'display'); ?></a>
			</h1>
			<a class="header__nav" href="#nav">
				<span><?php _e('jump to navigation', 'neko'); ?></span>
				<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--nav"></use></svg>
			</a>
			<a class="header__search" href="<?php echo home_url( '/?s=' ); ?>">
				<span><?php _e('jump to search', 'neko'); ?></span>
				<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--search"></use></svg>
			</a>
		</div>
	</header>
	<!--/#header-->

