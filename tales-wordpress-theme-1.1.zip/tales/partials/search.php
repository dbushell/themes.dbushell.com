<div class="modal search-modal" id="search" role="search">
	<div class="modal__align">
		<form class="search-modal__form" method="get" action="<?php echo home_url( '/' ); ?>">
			<label for="s"><?php _e('Search', 'neko'); ?></label>
			<input  class="field search-modal__criteria" type="search" name="s" id="s" placeholder="<?php _e('Search', 'neko'); ?>&hellip;">
			<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--search"></use></svg>
		</form>
	</div>
</div>
<!--/#search-->
