
	<div class="block comments" id="comments">
		<div class="block__align">

			<div class="block__body">

				<div class="comments__header">
					<h2 class="h1"><?php comments_number(); ?></h2>
				</div>

				<ol class="comments__list">
				<?php wp_list_comments(array('callback' => 'neko__comment')); ?>
				</ol>

				<div class="comments__footer">
					<p><?php paginate_comments_links(array('prev_text' => __('Previous', 'neko'), 'next_text' => __('Next', 'neko'))); ?></p>
				</div>
<?php

$commenter = wp_get_current_commenter();
$req = get_option('require_name_email');
$aria_req = ($req ? " aria-required='true'" : '');

$fields =  array(
  'author' =>
	'<div class="form__item"><label for="comment-form__author">' . __('Name', 'neko') .
	( $req ? '<span class="required">*</span>' : '' ) .  '</label> ' .
	'<input class="field" id="comment-form__author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" ' . $aria_req . '></div>',

  'email' =>
	'<div class="form__item"><label for="comment-form__email">' . __('Email', 'neko') .
	( $req ? '<span class="required">*</span>' : '' ) . '</label> ' .
	'<input class="field" id="comment-form__email" name="email" type="email" placeholder="me@example.com&hellip;" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" ' . $aria_req . '></div>',

  'url' =>
	'<div class="form__item"><label for="comment-form__url">' . __('Website', 'neko') . '</label>' .
	'<input class="field" id="comment-form__url" name="url" type="text" placeholder="http://www.example.com" value="' . esc_attr( $commenter['comment_author_url'] ) . '"></div>',
);

$args = array(
	'id_form'   => 'form-comment',
	'id_submit' => 'form-comment__submit',

	'fields'        => apply_filters('comment_form_default_fields', $fields),
	'comment_field' => '<div class="form__item"><label for="form-comment__body">' . __('Comment', 'neko') . '</label><textarea class="field" id="form-comment__body" name="comment" aria-required="true"></textarea></div>'
);

if (comments_open()) {
?>
<div class="form form--aligned comments__form">
<?php
	comment_form($args);
?>
</div>
<?php
} else {

}
?>

			</div>

		</div>
	</div>
