<?php

$next_url = '';
$previous_url = '';

if (preg_match( '#href="([^"]*)"#is', get_next_posts_link(), $matches)) {
	$next_url = trim($matches[1]);
}
if (preg_match( '#href="([^"]*)"#is', get_previous_posts_link(), $matches)) {
	$previous_url = trim($matches[1]);
}

if ($next_url || $previous_url) {
?>
	<div class="archives__pages">
		<p>
			<?php if (!empty($next_url)) { ?>
			<a href="<?php echo $next_url; ?>" class="archives__older">
				<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--arrow--left"></use></svg>
				<span><?php _e('Previous', 'neko'); ?></span>
			</a>
			<?php } ?>
			<?php if (!empty($previous_url)) { ?>
			<a href="<?php echo $previous_url; ?>" class="archives__newer">
				<span><?php _e('Next', 'neko'); ?></span>
				<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--arrow--right"></use></svg>
			</a>
			<?php } ?>
		</p>
	</div>
<?php } ?>
