	<meta charset="<?php bloginfo('charset'); ?>">

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title><?php wp_title('-', true, 'right'); ?><?php bloginfo('name', 'display'); ?></title>

	<!--[if (gt IE 8) | (IEMobile)]><!-->
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/style.css">
	<!--<![endif]-->
	<!--[if (lt IE 9) & (!IEMobile)]>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/oldie.css">
	<![endif]-->

<?php

if (is_singular()) {
	wp_enqueue_script('comment-reply');
}

wp_head();

?>
