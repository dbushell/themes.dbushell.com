<?php
global $root_object_id;

$page_for_posts = get_option('page_for_posts');
$banner_class    = 'block intro';
$banner_read     = false;
$banner_style    = '';
$banner_title    = '';
$banner_subtitle = 'none';

if (!is_singular() || is_numeric($root_object_id)) {
	$banner_class .= ' intro--offset';
}

if (is_home() || is_single() || is_page() || is_archive()) {

	if (is_singular()) {
		$post_id = $post->ID;
	} else {
		$post_id = $page_for_posts;
	}

	$banner_format        = get_post_meta($post_id, 'neko__banner_format', true);
	$banner_pattern       = get_post_meta($post_id, 'neko__banner_pattern', true);
	$banner_image_id      = get_post_meta($post_id, 'neko__banner_image_id', true);
	$banner_bg_color      = get_post_meta($post_id, 'neko__banner_bg_color', true);
	$banner_text_color    = get_post_meta($post_id, 'neko__banner_text_color', true);
	$banner_subtitle      = get_post_meta($post_id, 'neko__banner_subtitle', true);
	$banner_subtitle_text = get_post_meta($post_id, 'neko__banner_subtitle_text', true);

	if ($banner_subtitle === 'none' && is_front_page() && $post->post_type == 'page') {
		$desc = trim(get_bloginfo('description'));
		if (!empty($desc)) {
			$banner_subtitle = 'text';
			$banner_subtitle_text = $desc;
		}
	}

	if (!preg_match('/^#[0-9a-f]{3,6}$/i', $banner_bg_color)) {
		$banner_bg_color = 'transparent';
	}
	if (in_array($banner_format, array('half', 'cover'))) {
		$banner_style = '';
		$banner_class = 'block banner banner--'.$banner_format;
		// text colour
		if (!empty($banner_text_color)) {
			$banner_style .= "#banner * { color: {$banner_text_color} !important; fill: {$banner_text_color} !important; } \n";
		}
		// background colour
		if ($banner_bg_color !== 'transparent') {
			$banner_style .= "#banner { background-color: {$banner_bg_color}; } \n";
		}
		// background image
		if (!empty($banner_image_id)) {
			$image_meta = wp_get_attachment_metadata($banner_image_id);
			if (is_array($image_meta)) {
				if ($banner_pattern === 'on') {
					$banner_image = wp_get_attachment_image_src($banner_image_id, 'full');
					$banner_style .= "#banner { background-image: url('{$banner_image[0]}'); } \n";
					$banner_class .= ' banner--pattern';
				} else {
					$src = array(
						's' => wp_get_attachment_image_src($banner_image_id, 'neko__banner_s'),
						'm' => wp_get_attachment_image_src($banner_image_id, 'neko__banner_m'),
						'l' => wp_get_attachment_image_src($banner_image_id, 'neko__banner_l'),
						'x' => wp_get_attachment_image_src($banner_image_id, 'neko__banner_x')
					);
					$banner_style .= "#banner { background-image: url('{$src['x'][0]}'); } \n";
					$banner_style .= "@media screen and (min-width: 1em) { #banner { background-image: url('{$src['s'][0]}'); } } \n";
					if ($src['m'][0] != $src['s'][0]) {
						$ew = $src['s'][1] / 16;
						$eh = $src['s'][2] / 16;
						$banner_style .= "@media screen and (min-width: {$ew}em), screen and (min-height: {$eh}em) { #banner { background-image: url('{$src['m'][0]}'); } } \n";
					}
					if ($src['l'][0] != $src['m'][0]) {
						$ew = $src['m'][1] / 16;
						$eh = $src['m'][2] / 16;
						$banner_style .= "@media screen and (min-width: {$ew}em), screen and (min-height: {$eh}em) { #banner { background-image: url('{$src['l'][0]}'); } } \n";
					}
					if ($src['x'][0] != $src['l'][0]) {
						$ew = $src['l'][1] / 16;
						$eh = $src['l'][2] / 16;
						$banner_style .= "@media screen and (min-width: {$ew}em), screen and (min-height: {$eh}em) { #banner { background-image: url('{$src['x'][0]}'); } } \n";
					}
				}
			}
		}
		if ($banner_format === 'cover') {
			$banner_read = true;
		}
	}
}
?>
	<div class="<?php echo $banner_class; ?>" id="banner">
<?php
if (!empty($banner_style)) {
	echo '<style type="text/css" scoped>'."\n".$banner_style.'</style>';
}
?>

		<div class="block__align">
			<div class="block__body">
<?php
if (is_singular()) {
	$title = get_the_title();
	if (!strlen($title)) {
		$title = get_the_date(get_option('date_format'));
	}
?>
				<h1><?php echo $title; ?></h1>
<?php

} else {

	if ($page_for_posts) {
		$banner_title = get_the_title($page_for_posts);
	} else {
		$banner_title = __('Latest Articles', 'neko');
	}

	if (is_404()) {
		$banner_title = __('Page not found (404)', 'neko');
	}
	if (is_search()) {
		$banner_title = __('Search', 'neko');
	}
	if (is_author()) {
		$banner_title = get_the_author();
	}
	if (is_year()) {
		$banner_title = get_the_date('Y');
	}
	if (is_month()) {
		$banner_title = get_the_date('F, Y');
	}
	if (is_day()) {
		$banner_title = get_the_date(get_option('date_format'));
	}
	if (is_tag()) {
		$banner_title = single_tag_title('', false);
	}
	if (is_category()) {
		$banner_title = single_cat_title('', false);
	}

?>
				<h1><?php echo esc_html($banner_title); ?></h1>
<?php } ?>
			<?php if ($banner_subtitle === 'date') { ?>
				<p class="h--sub"><?php echo get_the_date(get_option('date_format')); ?></p>
			<?php } else if ($banner_subtitle === 'text' && !empty($banner_subtitle_text)) { ?>
				<p class="h--sub"><?php echo $banner_subtitle_text; ?></p>
			<?php } ?>
			</div>
		</div>
<?php if ($banner_read) { ?>
		<a class="banner__read" href="#content" data-scroll="true">
			<span><?php _e('Read Article', 'neko'); ?></span>
			<svg class="svg--icon" viewBox="0 0 30 16"><use xlink:href="#svg--scroll--down"></use></svg>
		</a>
<?php } ?>
	</div>
