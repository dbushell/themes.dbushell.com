<?php
$copyright_name = trim(get_theme_mod('neko__copyright_name'));
if (empty($copyright_name)) {
	$copyright_name = get_bloginfo('name', 'display');
}
?>
			<div class="footer__small">
				<p class="p--small"><small><?php _e('Copyright', 'neko'); ?> &copy; <?php echo esc_html($copyright_name); ?></small></p>
			</div>
