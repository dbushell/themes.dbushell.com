<?php

global $root_object_id, $parent;

?>
			<?php if ($root_object_id) { ?>
					<aside class="block__aside">
						<div class="menu menu--collapsed">
							<h2 class="menu__title">
								<span><?php echo apply_filters('the_title', $parent->post_title); ?></span>
								<?php _e('Navigation', 'neko'); ?>
							</h2>
							<ul class="menu__list"><?php
							wp_nav_menu(array(
								'theme_location'       => 'primary',
								'neko__root_object_id' => $root_object_id,
								'depth'                => 2,
								'container'            => false,
								'items_wrap'           => '%3$s',
								'fallback_cb'          => 'neko__Walker_Nav_Section::fallback',
								'walker'               => new neko__Walker_Nav_Section())
							);
							?></ul>
							<button class="link menu__toggle">
								<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--nav"></use></svg>
							</button>
						</div>
					</aside>
			<?php } ?>
