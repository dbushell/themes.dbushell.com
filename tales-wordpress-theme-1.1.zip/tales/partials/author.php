<?php
$author_ID = get_the_author_meta('ID');
preg_match('/src=\'(.*?)\'/i', get_avatar($author_ID, 100), $avatar);
$avatar = $avatar[1];
?>
	<div class="block bio">
		<div class="block__align">
			<aside class="block__body">
				<div class="bio__photo">
					<img src="<?php echo $avatar; ?>" alt="<?php the_author_meta('display_name'); ?>">
				</div>
				<div class="bio__body">
					<h3 class="bio__name"><em><?php _e('Written by', 'neko'); ?></em> <?php the_author_meta('display_name'); ?></h3>
					<p class="p--small"><?php the_author_meta('description'); ?></p>
				</div>
			</aside>
		</div>
	</div>
