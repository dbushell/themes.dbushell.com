
	<nav class="nav" id="nav" role="navigation">
		<div class="nav__inner">
			<h2 class="nav__title"><?php _e('Navigation', 'neko'); ?></h2>
<?php

wp_nav_menu(array(
	'theme_location'    => 'primary',
	'depth'             => 1,
	'container'         => false,
	'menu_id'           => 'nav__list',
	'menu_class'        => 'nav__list',
	'fallback_cb'       => 'neko__Walker_Nav::fallback',
	'walker'            => new neko__Walker_Nav())
);

?>
			<a class="nav__return" href="#top">
				<span><?php _e('return to top of page', 'neko'); ?></span>
				<svg class="svg--icon" viewBox="0 0 28 28"><use xlink:href="#svg--close"></use></svg>
			</a>
		</div>
	</nav>
	<!--/#nav-->
