<?php get_template_part("header"); ?>

<main class="main" id="main" role="main">

<?php get_template_part('partials/banner'); ?>

<?php
rewind_posts();
if (have_posts()) {
	while (have_posts()) {
		the_post();
		$post_class = get_post_class();
?>
	<div class="block article" id="content">
		<div class="block__align">
			<div class="block__body prose <?php echo implode($post_class, ' '); ?>" id="post-<?php the_ID(); ?>">
				<?php the_content(); ?>
				<?php wp_link_pages(array('before' => '<hr class="hr--light"><p>'.__('Pages','neko').':', 'after' => '</p>')); ?>
				<div class="article__meta">
					<hr class="hr--light">
					<?php the_tags('<p class="p--small">'.__('Tags: ', 'neko'), ', ', '</p>'); ?>
					<p class="p--small"><?php echo __('Categories: ', 'neko'); the_category(', '); ?></p>
				</div>
			</div>
		</div>
	</div>
<?php
	$comments_count = wp_count_comments(get_the_ID());
	}
}
?>

<?php
get_template_part('partials/author');

if ($comments_count->approved || comments_open()) {
	comments_template('/partials/comments.php');
}
?>

</main>
<!--/#main-->

<?php get_template_part("footer"); ?>
