
Thank you for purchasing the Tales WordPress theme!

License:
http://themes.dbushell.com/tales/license/

Documentation and developer guides:
http://themes.dbushell.com/tales/documentation/

 - David Bushell ( david@dbushell.com / @dbushell )
